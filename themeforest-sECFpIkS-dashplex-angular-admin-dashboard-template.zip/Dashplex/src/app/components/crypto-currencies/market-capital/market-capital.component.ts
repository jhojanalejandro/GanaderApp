import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-market-capital',
  templateUrl: './market-capital.component.html',
  styleUrls: ['./market-capital.component.scss']
})
export class MarketCapitalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
