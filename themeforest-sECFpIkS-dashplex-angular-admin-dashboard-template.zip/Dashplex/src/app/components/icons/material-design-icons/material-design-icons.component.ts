import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-material-design-icons',
  templateUrl: './material-design-icons.component.html',
  styleUrls: ['./material-design-icons.component.scss']
})
export class MaterialDesignIconsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
