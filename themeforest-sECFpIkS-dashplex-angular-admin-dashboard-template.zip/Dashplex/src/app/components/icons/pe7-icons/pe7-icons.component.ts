import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pe7-icons',
  templateUrl: './pe7-icons.component.html',
  styleUrls: ['./pe7-icons.component.scss']
})
export class Pe7IconsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
